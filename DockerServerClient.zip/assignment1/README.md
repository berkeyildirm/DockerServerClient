# Docker and Containers Assignment1

# How to Run

```
$ docker compose up
```